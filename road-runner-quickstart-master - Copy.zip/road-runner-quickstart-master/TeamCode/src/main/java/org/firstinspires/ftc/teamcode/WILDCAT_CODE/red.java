package org.firstinspires.ftc.teamcode.WILDCAT_CODE;

import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.Vector2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;

import org.firstinspires.ftc.teamcode.MecanumDrive;

@Autonomous
public final class red extends LinearOpMode {
    public DcMotorEx launcher;
    public static double kP = 1000;
    public static double kI = 0;
    public static double kD = 0;
    public static double kF = 15;
    public static double TARGET_VELOCITY = 1300; // Ticks per second

    @Override
    public void runOpMode() throws InterruptedException {
        Pose2d beginPose = new Pose2d(0, 0, 0);
        if (TuningOpModes.DRIVE_CLASS.equals(MecanumDrive.class)) {
            MecanumDrive drive = new MecanumDrive(hardwareMap, beginPose);
            Stopper stopper = new Stopper(hardwareMap);
            launcher = hardwareMap.get(DcMotorEx.class, "launcher");
            DcMotor intake = hardwareMap.dcMotor.get("intake");
            DcMotor transfer = hardwareMap.dcMotor.get("transfer");
            intake.setDirection(DcMotorSimple.Direction.REVERSE);
            launcher.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
            //launcher.setDirection(DcMotorSimple.Direction.REVERSE);
            // PIDFCoefficients pidfCoefficients = new PIDFCoefficients(P,1000,15,F);
            // launcher.setPIDFCoefficients(DcMotor.R`````````````````````````````````````````````unMode.RUN_USING_ENCODER, pidfCoefficients);
            launcher.setPIDFCoefficients(DcMotor.RunMode.RUN_USING_ENCODER, new PIDFCoefficients(kP, kI, kD, kF));

            waitForStart();

            launcher.setPower(1);
            intake.setPower(0.9);
            transfer.setPower(0.5);


            Actions.runBlocking(
                    drive.actionBuilder(beginPose)
                            .strafeTo(new Vector2d(-24, 0))
                            .afterTime(0, stopper.stopperOpen())
                            .waitSeconds(10)




                            .build());
            stopper.stopperOpen();

            Actions.runBlocking(
                    drive.actionBuilder(new Pose2d(new Vector2d(-25,0),0))

                            .waitSeconds(1)
                            .turn(Math.toRadians(90))
                            .waitSeconds(1)
                            .afterTime(0, stopper.stopperClose())
                            .strafeTo(new Vector2d(-25,25))
                            .waitSeconds(1)
                            .turn(Math.toRadians(-60))
                            .waitSeconds(1)
                            .strafeTo(new Vector2d(-6,30))
                            .waitSeconds(1)
                            .strafeTo(new Vector2d(-18,0))
                            .waitSeconds(1)
                            .turn(Math.toRadians(-15))
                            .afterTime(0, stopper.stopperOpen())
                            .waitSeconds(1)
                            .strafeTo(new Vector2d(7,43.4))
                            .afterTime(0, stopper.stopperClose())
                            .waitSeconds(1)


                            .build());
        }
        }
    }
