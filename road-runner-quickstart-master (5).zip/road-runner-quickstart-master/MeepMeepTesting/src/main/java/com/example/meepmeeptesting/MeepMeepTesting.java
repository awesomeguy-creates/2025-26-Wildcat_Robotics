package com.example.meepmeeptesting;

import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.Vector2d;
import com.noahbres.meepmeep.MeepMeep;
import com.noahbres.meepmeep.roadrunner.DefaultBotBuilder;
import com.noahbres.meepmeep.roadrunner.entity.RoadRunnerBotEntity;

public class MeepMeepTesting {
    public static void main(String[] args) {
        MeepMeep meepMeep = new MeepMeep(800);

        RoadRunnerBotEntity myBot = new DefaultBotBuilder(meepMeep)
                // Set bot constraints: maxVel, maxAccel, maxAngVel, maxAngAccel, track width
                .setConstraints(60, 60, Math.toRadians(180), Math.toRadians(180), 15)
                .build();

        myBot.runAction(myBot.getDrive().actionBuilder(new Pose2d(0, 0, 0))
                .strafeTo(new Vector2d(-25, 0))
                .waitSeconds(1)
                .strafeTo(new Vector2d(-25, 0))
                .waitSeconds(1)
                .turn(Math.toRadians(95))
                .waitSeconds(1)
                .strafeTo(new Vector2d(-25,25))
                .waitSeconds(1)
                .turn(Math.toRadians(-60))
                .waitSeconds(1)
                .strafeTo(new Vector2d(0,37))
                .waitSeconds(1)
                .strafeTo(new Vector2d(-25,25))
                .waitSeconds(1)
                .strafeTo(new Vector2d(-10,-10))
                .waitSeconds(1)
                .turn(Math.toRadians(-25))
                .waitSeconds(1)
                .turn(Math.toRadians(25))
                .waitSeconds(1)
                .strafeTo(new Vector2d(5,20))
                .waitSeconds(1)
                .strafeTo(new Vector2d(-10,-10))
                .waitSeconds(1)
                .strafeTo(new Vector2d(-10,30))
                .turn(Math.toRadians(-25))
                .build());

        meepMeep.setBackground(MeepMeep.Background.FIELD_DECODE_JUICE_BLACK)
                .setDarkMode(true)
                .setBackgroundAlpha(0.95f)
                .addEntity(myBot)
                .start();
    }
}