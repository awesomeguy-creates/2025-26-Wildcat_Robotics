package org.firstinspires.ftc.teamcode.tuning;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.PIDFCoefficients;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.DcMotor.RunMode;

@TeleOp
public class MecanumTeleOp extends LinearOpMode {
    public DcMotorEx launcher;
    public static double kP = 1000;
    public static double kI = 0;
    public static double kD = 0;
    public static double kF = 15;
    public static double TARGET_VELOCITY = 1500; // Ticks per second

    @Override
    public void runOpMode() throws InterruptedException {

        // Declare our motors
        // Make sure your ID's match your configuration
        DcMotor leftFront = hardwareMap.dcMotor.get("leftFront");
        DcMotor leftBack = hardwareMap.dcMotor.get("leftBack");
        DcMotor rightFront = hardwareMap.dcMotor.get("rightFront");
        DcMotor rightBack = hardwareMap.dcMotor.get("rightBack");
        launcher = hardwareMap.get(DcMotorEx.class, "launcher");
        DcMotor intake = hardwareMap.dcMotor.get("intake");
        DcMotor transfer = hardwareMap.dcMotor.get("transfer");
        Servo stopper = hardwareMap.get(Servo.class, "stopper");
        Servo diverter = hardwareMap.get(Servo.class, "diverter");


        //tester code delete after
        Servo left_pusher = hardwareMap.get(Servo.class, "left_pusher");
        Servo right_pusher = hardwareMap.get(Servo.class, "left_pusher");
     //   double F = 15;

       // double P = 1000;
        launcher.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        //launcher.setDirection(DcMotorSimple.Direction.REVERSE);
       // PIDFCoefficients pidfCoefficients = new PIDFCoefficients(P,1000,15,F);
       // launcher.setPIDFCoefficients(DcMotor.R`````````````````````````````````````````````unMode.RUN_USING_ENCODER, pidfCoefficients);
        launcher.setPIDFCoefficients(RunMode.RUN_USING_ENCODER, new PIDFCoefficients(kP, kI, kD, kF));

        stopper.setPosition(0.8);
        diverter.setPosition(0.48);
        left_pusher.setPosition(0.4);
        right_pusher.setPosition(0.4);
        //left_pusher.setPosition(0.1);

        //right_pusher.setPosition(0.25);
       // left_pusher.setPosition(0.25);

        // Reverse the right side motors. This may be wrong for your setup.
        // If your robot moves backwards when commanded to go forwards,
        // reverse the left side instead.
        // See the note about this earlier on this page.
        leftFront.setDirection(DcMotorSimple.Direction.REVERSE);
        leftBack.setDirection(DcMotorSimple.Direction.REVERSE);
        intake.setDirection(DcMotorSimple.Direction.REVERSE);

        waitForStart();

        if (isStopRequested()) return;





        //intake.setPower(0.75);
        //transfer.setPower(1);

        while (opModeIsActive()) {
            launcher.setVelocity(TARGET_VELOCITY);

            if (gamepad1.a) {

                stopper.setPosition(0); // Move to position 1 (e.g., open)

                intake.setPower(0.75);
                transfer.setPower(0.5);
                launcher.setPower(1);
            }

            // --- Servo Control Logic ---
            // Use gamepad buttons
            //
            //
            //
            // ns to control the servo

           //intake
            if (gamepad1.x) {
                //INCREASE THIS TOMARRROW
                intake.setPower(0.9);
                stopper.setPosition(0.8); // Move to position 0.5 (e.g., halfway)
                transfer.setPower(0.3);

            }
            if (gamepad1.y) {
                intake.setPower(0);
                transfer.setPower(0);
                stopper.setPosition(0.8);

            }
            //launch

            if (gamepad1.b) {
                intake.setPower(0);
                transfer.setPower(0);
                stopper.setPosition(0.8);

            }

           /* if (gamepad2.y) {
                launcher.setPower(1);

            }
            //launch
            if (gamepad2.x) {
                launcher.setPower(0.5);

            }
            if (gamepad2.a) {
                launcher.setPower(0);

            }*/




            double y = -gamepad1.left_stick_y; // Remember, Y stick value is reversed
            double x = gamepad1.left_stick_x * 1.1; // Counteract imperfect strafing
            double rx = gamepad1.right_stick_x;

            // Denominator is the largest motor power (absolute value) or 1
            // This ensures all the powers maintain the same ratio,
            // but only if at least one is out of the range [-1, 1]
            double denominator = Math.max(Math.abs(y) + Math.abs(x) + Math.abs(rx), 1);
            double leftFrontPower = (y + x + rx) / denominator;
            double leftBackPower = (y - x + rx) / denominator;
            double rightFrontPower = (y - x - rx) / denominator;
            double rightBackPower = (y + x - rx) / denominator;

            leftFront.setPower(leftFrontPower);
            leftBack.setPower(leftBackPower);
            rightFront.setPower(rightFrontPower);
            rightBack.setPower(rightBackPower);

        }
        }
}
