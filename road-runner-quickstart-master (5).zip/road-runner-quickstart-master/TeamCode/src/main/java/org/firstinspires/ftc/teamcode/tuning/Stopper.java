package org.firstinspires.ftc.teamcode.tuning;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

public class Stopper {
    public Servo stopper;

    public Stopper(HardwareMap hardwareMap){

        stopper = hardwareMap.get(Servo.class, ("stopper"));

        stopper.setDirection(Servo.Direction.FORWARD);

    }

    public class stopperOpen implements Action {
        @Override

        public boolean run(@NonNull TelemetryPacket packet){
            stopper.setPosition(0);

            return false;
        }
    }

    public Action stopperOpen(){
        return new stopperOpen();
    }
    public class stopperClose implements Action {
        @Override

        public boolean run(@NonNull TelemetryPacket packet){
            stopper.setPosition(0.8);

            return false;
        }
    }

    public Action stopperClose(){
        return new stopperClose();
    }
}

